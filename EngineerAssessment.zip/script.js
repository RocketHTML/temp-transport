//Place JS below
document.getElementById("change_element").addEventListener("click", function(){
    document.getElementById("script-code").style.background = 'yellow'
})